// import React from 'react'

// function DisplaySeatsCount() {
//     return (
        
//     )
// }

// export default DisplaySeatsCount